﻿namespace CrawlerMVC.Models.EmailModels
{
    public class NotificationType
    {
        public Guid NotificationTypeId { get; set; }

        public string NotificationName { get; set; }

    }
}

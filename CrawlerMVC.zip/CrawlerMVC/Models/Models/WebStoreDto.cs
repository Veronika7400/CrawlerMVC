﻿using System.ComponentModel.DataAnnotations;

namespace WebApiCrawler.Models
{
    public class WebStoreDto
    {
        public string Name { get; set; }
    }
}
